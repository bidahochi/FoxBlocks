package codechicken.lib.render;

public interface IFaceRenderer
{
    public void renderFace(Vertex5[] face, int side);
}
