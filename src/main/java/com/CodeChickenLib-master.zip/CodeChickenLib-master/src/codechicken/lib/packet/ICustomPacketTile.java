package codechicken.lib.packet;

public interface ICustomPacketTile
{
    public void handleDescriptionPacket(PacketCustom packet);
}
