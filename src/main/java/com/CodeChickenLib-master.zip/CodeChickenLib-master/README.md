CodeChickenLib
==============
THIS PROJECT IS RETIRED: See [here] for the current repo.

This is a library of systems to help make various aspects of minecraft modding easier.
It contains libraries for 3D math and transformations, model rendering, packets, config, colours, asm and a few other things.

Current maven: http://chickenbones.net/maven/

Join us on IRC:
- Server: Esper.net
- Channel: #ChickenBones


[here]: <https://github.com/TheCBProject/CodeChickenLib>
